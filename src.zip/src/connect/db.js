require('dotenv').config();
const mysql = require('mysql2');

const db = mysql.createpool({
      host: Process.env.DB_HOST,
      user: Process.env.DB_USER,
      password: Process.env.DB_PASSWORD,
      database: Process.env.DB_NAME,
      waitforConnections: true,
      connectionLimit: 10,
      queueLimit: 0
});db.getConnection((err, connection) => {
      if (err) {
            console.eror(err)
            return;
      }
      console.log('berhasil');
      connection.release();
});

module.exports = db;