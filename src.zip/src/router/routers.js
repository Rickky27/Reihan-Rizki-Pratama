const express=require ('express');
const routers = express.Router();
const todoControl = require('../control/todoControls');


routers.get('/', todoControl.getTodo);

module.exports = routers;