const db = require('../connect/db');

const Todo = {
      getAllTodo: (callback) => {
            db.query('SELECT * From data', callback);
      },
};

module.exports = Todo;